Read Me:

Version Info:
Version 0.0.2.0

Special Instrucitions:
Follow the instructions in game.
"Use mouse to move" means the character follows the mouse.

Known Bugs:
- Sometimes The snowball will go past it's bounds, then turn around, but not go back far enough, and flick back and forth on the boundary.